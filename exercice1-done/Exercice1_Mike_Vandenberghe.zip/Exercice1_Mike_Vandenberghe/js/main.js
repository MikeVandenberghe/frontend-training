$(document).ready(function(){
    
    // Middle of my page 
    
    window.scrollTo(0, ($(document).height() /2) - 350);
    
    // Actions when i go to the left
    
    $('.form').hide();
    $('.backToMiddle').hide;
    
    var clickBgLeft = function(){
            
        // Scrolling 
        $('html, body').animate({ scrollTop: 0}, 800);
        
        // Bg Position
        $('.bgLeft').animate({'background-position': '0px'}, 400);
        
        // Title Animation
        $('.intro').animate({top: '70%'}, 600);
        $('.intro h2').fadeOut(300);
        
        // Form Animation
        $('.form').show();
        $('.form').animate({ opacity: 1, marginLeft: "-215px" }, 'slow');
        
        // Back Button Animation
        $('.backToMiddle').show();
        $('.backToMiddle').animate({ opacity: 1, left: "-2.7%" }, 'slow');
        
        // Remove hover event after the click
        $('.bgLeft').unbind("mouseover mouseout click");
        $('.bgLeft').attr('style', 'cursor:default;');
        
    };
    
    $('.bgLeft').click(clickBgLeft);
    
    // Actions when i go to the right
    
    var clickBgRight = function(){
        
        // Scrolling 
        $('html, body').animate({ scrollTop: $(document).height()}, 800);
        
        // Bg Position
        $('.bgRight').animate({'background-position': '0px'}, 400);
        
        // Title Animation
        $('.intro').animate({top: '70%'}, 600);
        $('.intro h2').fadeOut(300);
        
        // Form Animation
        $('.form').show();
        $('.form').animate({ opacity: 1, marginLeft: "-215px" }, 'slow');
        
        // Back Button Animation
        $('.backToMiddle').show();
        $('.backToMiddle').animate({ opacity: 1, left: "-2.7%" }, 'slow');
        
        // Remove hover event after the click
        $('.bgRight').unbind("mouseover mouseout click");
        $('.bgRight').attr('style', 'cursor:default;');
    
    }; 
        
    $('.bgRight').click(clickBgRight);
    
    // Actions when i go back to the middle of my page
    
    $(".backToMiddle").click(function(){
        
        // Scrolling
        $('html, body').animate({ scrollTop: ($(document).height() /2) - 350}, 800);
        
        // Title Animation
        setTimeout(function(){
            $('.intro h2').fadeIn(500);
            $('.intro').animate({top: '50%'}, 500);
        }, 500);
            
        // Form Animation
        $('.form').animate({ opacity: 0, marginLeft: "-350px" }, 'slow');
        setTimeout(function(){
            $('.form').hide();
            $('.backToMiddle').hide();
        }, 500);
        
        // Back Button Animation
        $(this).animate({ opacity: 0, left: "-5.7%" }, 'slow');
        
        // Bg Position
        setTimeout(function(){
            $('.bgLeft').animate({'background-position': '-350px'}, 600);
        }, 200);
     
        setTimeout(function(){
            $('.bgRight').animate({'background-position': '350px'}, 600);
        }, 200);
        
        // Recover Attributes 
        setTimeout(function(){
            $('.bgLeft').bind("click", clickBgLeft);
            $('.bgLeft').bind("mouseover", mouseoverBgLeft);
            $('.bgLeft').bind("mouseout", mouseoutBgLeft);
            $('.bgRight').bind("click", clickBgRight);
            $('.bgRight').bind("mouseover", mouseoverBgRight);
            $('.bgRight').bind("mouseout", mouseoutBgRight);
            $('.bgLeft, .bgRight').attr('style', 'cursor:pointer;');
        }, 1000);        
    });
    
    // Hover Effects
    
    // Back Button (Out/Over)
    $(".backToMiddle").mouseover(function(){
        $(this).animate({left: '-1%'}, 200);    
    });

    $(".backToMiddle").mouseout(function(){
        $(this).animate({left: '-2.7%'}, 200);
    });

    // Left Screen (Out/Over) 
    var mouseoutBgLeft = function(){
        $('html, body').animate({ scrollTop: ($(document).height() /2) - 350}, { duration: 200, queue: false });
        $('.bgRight').animate({opacity: 1}, { duration: 300, queue: false });
        $('.bgRight').animate({'background-position': '350px'}, { duration: 300, queue: false });
        $('.bgLeft').animate({'background-position': '-350px'}, { duration: 300, queue: false });           
    };
    
    $('.bgLeft').mouseout(mouseoutBgLeft);

    var mouseoverBgLeft = function(){
        $('html, body').animate({ scrollTop: ($(document).height() /2) - 375}, 200);
        $('.bgRight').animate({opacity: 0.5}, { duration: 300, queue: false });
        $('.bgRight').animate({'background-position': '375px'}, { duration: 300, queue: false });
        $('.bgLeft').animate({'background-position': '-325'}, { duration: 300, queue: false });   
    };

    $('.bgLeft').mouseover(mouseoverBgLeft);

    // Right Screen (Out/Over
    var mouseoutBgRight = function(){
        $('html, body').animate({ scrollTop: ($(document).height() /2) - 350}, { duration: 200, queue: false });
        $('.bgLeft').animate({opacity: 1}, { duration: 300, queue: false });
        $('.bgLeft').animate({'background-position': '-350px'}, { duration: 300, queue: false });
        $('.bgRight').animate({'background-position': '350px'}, { duration: 300, queue: false });
    };

    $('.bgRight').mouseout(mouseoutBgRight);

    var mouseoverBgRight = function(){
        $('html, body').animate({ scrollTop: ($(document).height() /2) - 325}, 200);
        $('.bgLeft').animate({opacity: 0.5}, { duration: 300, queue: false });
        $('.bgLeft').animate({'background-position': '-375px'}, { duration: 300, queue: false });
        $('.bgRight').animate({'background-position': '325px'}, { duration: 300, queue: false });
    };

    $('.bgRight').mouseover(mouseoverBgRight);
});

// Invert Scroll 

    (function($) {
        $.jInvertScroll(['.scroll'],        
            {
            height: 4000
        });
    }(jQuery));